﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShopManagement
{
    public partial class Form1 : Form
    {
        int inEmpId = 0;
        bool isDefaultImage = true;
        string strConnectionString = @"Data Source=DESKTOP-IOJRT48;Database=Shop_DB;Integrated Security=True", strPreviousImage = "";
        OpenFileDialog ofd = new OpenFileDialog();
        public Form1()
        {
            InitializeComponent();
        }
        private void btnReset_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            PositionComboBoxFile();
            FillEmployeeDataGridView();
            Clear();
        }

        void Clear()
        {
            txtEmpCod.Text = txtEmpName.Text = "";
            cmbPosition.SelectedIndex = CmbGender.SelectedIndex = 0;
            dtpDOB.Value = DateTime.Now;
            rbtRegular.Checked = true;
            if (dgvShop.DataSource == null)
                dgvShop.Rows.Clear();
            else dgvShop.DataSource = (dgvShop.DataSource as DataTable).Clone();
            inEmpId = 0;
            btnSave.Text = "Save";
            btnDelete.Enabled = false;
            pbxPhoto.Image = Image.FromFile(Application.StartupPath + "\\Images\\DefaultImage.png");
            isDefaultImage = false;
        }

        private void btnImageBrowser_Click(object sender, EventArgs e)
        {
            ofd.Filter = "Images(.jpg,.png) | *.png; *.jpg";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pbxPhoto.Image = new Bitmap(ofd.FileName);

                isDefaultImage = false;
                strPreviousImage = "";
            }
        }

        private bool ValidateMasterDetaailsFor()
        {
            bool _IsValid = true;
            if (txtEmpName.Text.Trim() == "")
            {
                MessageBox.Show("Employee Name is Required");
                _IsValid = false;
            }

            return _IsValid;
        }
        private string SaveImage(string _ImagePath)
        {
            string _FileName = Path.GetFileNameWithoutExtension(_ImagePath);
            string _Extention = Path.GetExtension(_FileName);
            _FileName = _FileName.Length <= 15 ? _FileName : _FileName.Substring(0, 15);
            _FileName = _FileName + DateTime.Now.ToString("yymmssff") + _Extention;
            pbxPhoto.Image.Save(Application.StartupPath + "\\Images\\" + _FileName);
            return _FileName;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ValidateMasterDetaailsFor())
            {
                int _EmpID = 0;
                using (SqlConnection sqlcon = new SqlConnection(strConnectionString))
                {
                    sqlcon.Open();
                    SqlCommand sqlcmd = new SqlCommand("EmployeeAddOrEdit", sqlcon);
                    sqlcmd.CommandType = CommandType.StoredProcedure;
                    sqlcmd.Parameters.AddWithValue("@EmployeeId", inEmpId);
                    sqlcmd.Parameters.AddWithValue("@EmployeeCod", txtEmpCod.Text.Trim());
                    sqlcmd.Parameters.AddWithValue("@EmployeeName", txtEmpName.Text.Trim());
                    sqlcmd.Parameters.AddWithValue("@PositionId", Convert.ToInt32(cmbPosition.SelectedValue));
                    sqlcmd.Parameters.AddWithValue("@DOB", dtpDOB.Value);
                    sqlcmd.Parameters.AddWithValue("@Gender", CmbGender.Text);
                    sqlcmd.Parameters.AddWithValue("@Status", rbtRegular.Checked ? "Regular" : "Contractual");
                    if (isDefaultImage)
                        sqlcmd.Parameters.AddWithValue("@ImagePath", DBNull.Value);
                    else if (inEmpId > 0 && strPreviousImage != "")
                        sqlcmd.Parameters.AddWithValue("@ImagePath", strPreviousImage);
                    else
                        sqlcmd.Parameters.AddWithValue("@ImagePath", SaveImage(ofd.FileName));
                    _EmpID = Convert.ToInt32(sqlcmd.ExecuteScalar());
                }


                //Details
                using (SqlConnection sqlCon = new SqlConnection(strConnectionString))
                {
                    sqlCon.Open();
                    foreach (DataGridViewRow dgvRow in dgvShop.Rows)
                    {
                        if (dgvRow.IsNewRow) break;
                        else
                        {
                            SqlCommand sqlCmd = new SqlCommand("ShopAddOrEdit", sqlCon);
                            sqlCmd.CommandType = CommandType.StoredProcedure;
                            sqlCmd.Parameters.AddWithValue("@ShopId", Convert.ToInt32(dgvRow.Cells["dgvtxtShopId"].Value == DBNull.Value ? "0" : dgvRow.Cells["dgvtxtShopId"].Value));
                            sqlCmd.Parameters.AddWithValue("@EmployeeId", _EmpID);
                            sqlCmd.Parameters.AddWithValue("@ShopName", dgvRow.Cells["dgvtxtShopName"].Value == DBNull.Value ? "0" : dgvRow.Cells["dgvtxtShopName"].Value);
                            sqlCmd.Parameters.AddWithValue("@positionId", Convert.ToInt32(dgvRow.Cells["dgvcmbPosition"].Value == DBNull.Value ? "0" : dgvRow.Cells["dgvcmbPosition"].Value));
                            sqlCmd.Parameters.AddWithValue("@YearOfExp", Convert.ToInt32(dgvRow.Cells["dgvtxtYearOfExp"].Value == DBNull.Value ? "0" : dgvRow.Cells["dgvtxtYearOfExp"].Value));
                            sqlCmd.ExecuteNonQuery();
                        }
                    }
                }
                FillEmployeeDataGridView();
                Clear();
                MessageBox.Show("Submitted Successfully");
            }
        }

        private void FillEmployeeDataGridView()
        {
            using (SqlConnection sqlCon = new SqlConnection(strConnectionString))
            {

                sqlCon.Open();

                SqlDataAdapter sqlDa = new SqlDataAdapter("EmployeeViewAll", sqlCon);
                sqlDa.SelectCommand.CommandType = CommandType.StoredProcedure;
                DataTable dtbl = new DataTable();
                sqlDa.Fill(dtbl);
                dgvEmployee.DataSource = dtbl;
                dgvEmployee.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dgvEmployee.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                dgvEmployee.Columns[0].Visible = false;
            }
        }

        private void dgvEmployee_DoubleClick(object sender, EventArgs e)
        {
            if (dgvEmployee.CurrentRow.Index != -1)
            {
                DataGridViewRow _dgvCurrentRow = dgvEmployee.CurrentRow;
                inEmpId = Convert.ToInt32(_dgvCurrentRow.Cells[0].Value);
                using (SqlConnection sqlCon = new SqlConnection(strConnectionString))
                {
                    sqlCon.Open();
                    SqlDataAdapter sqlDa = new SqlDataAdapter("EmployeeViewById", sqlCon);
                    sqlDa.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDa.SelectCommand.Parameters.AddWithValue("@EmployeeId", inEmpId);

                    DataSet ds = new DataSet();
                    sqlDa.Fill(ds);

                    //Master - Fill
                    DataRow dr = ds.Tables[0].Rows[0];
                    txtEmpCod.Text = dr["EmployeeCod"].ToString();
                    txtEmpName.Text = dr["EmployeeName"].ToString();
                    cmbPosition.SelectedValue = Convert.ToInt32(dr["PositionId"].ToString());
                    dtpDOB.Value = Convert.ToDateTime(dr["DOB"].ToString());
                    CmbGender.Text = dr["Gender"].ToString();
                    if (dr["Status"].ToString() == "Regular")
                        rbtRegular.Checked = true;

                    else rbtContractual.Checked = true;

                    if (dr["ImagePath"] == DBNull.Value)
                    {
                        pbxPhoto.Image = new Bitmap(Application.StartupPath + "\\Images\\DefaultImage.png");
                        isDefaultImage = true;
                    }
                    else
                    {
                        pbxPhoto.Image = new Bitmap(Application.StartupPath + "\\Images\\" + dr["ImagePath"].ToString());
                        strPreviousImage = dr["ImagePath"].ToString();
                        isDefaultImage = true;
                    }
                    dgvShop.AutoGenerateColumns = false;
                    dgvShop.DataSource = ds.Tables[1];
                    btnDelete.Enabled = true;
                    btnSave.Text = "Update";
                    tabControl1.SelectedIndex = 0;
                }
            }
        }

        private void dgvShop_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
            DataGridViewRow dgvRow = dgvShop.CurrentRow;
            if (dgvRow.Cells["dgvtxtShopId"].Value != DBNull.Value)
            {
                if (MessageBox.Show("Are You Sure To Delete This Record?", "Master Details CRUD", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    using (SqlConnection sqlCon = new SqlConnection(strConnectionString))
                    {
                        sqlCon.Open();
                        SqlCommand sqlcmd = new SqlCommand("ShopDelete", sqlCon);
                        sqlcmd.CommandType = CommandType.StoredProcedure;
                        sqlcmd.Parameters.AddWithValue("@ShopId", Convert.ToInt32(dgvRow.Cells["dgvtxtShopId"].Value));
                        sqlcmd.ExecuteNonQuery();
                    }
                }
                else
                    e.Cancel = true;
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You Sure To Delete This Record?", "Master Details CRUD", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                using (SqlConnection sqlCon = new SqlConnection(strConnectionString))
                {
                    sqlCon.Open();
                    SqlCommand sqlcmd = new SqlCommand("EmployeeDelete", sqlCon);
                    sqlcmd.CommandType = CommandType.StoredProcedure;
                    sqlcmd.Parameters.AddWithValue("@EmployeeId", inEmpId);
                    sqlcmd.ExecuteNonQuery();
                    Clear();
                    FillEmployeeDataGridView();
                    MessageBox.Show("Deleted Successfully");
                };

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmShop shop= new frmShop();

             shop.ShowDialog();
        }

        void PositionComboBoxFile()
        {
            using (SqlConnection sqlcon = new SqlConnection(strConnectionString))
            {
                sqlcon.Open();
                SqlDataAdapter sqlda = new SqlDataAdapter("select * from Positions", sqlcon);
                DataTable dtbl = new DataTable();
                sqlda.Fill(dtbl);
                DataRow topItem = dtbl.NewRow();
                topItem[0] = 0;
                topItem[1] = "--Select--";
                dtbl.Rows.InsertAt(topItem, 0);
                cmbPosition.ValueMember = dgvcmbPosition.ValueMember = "PositionId";
                cmbPosition.DisplayMember = dgvcmbPosition.DisplayMember = "Position";
                cmbPosition.DataSource = dtbl;
                dgvcmbPosition.DataSource = dtbl.Copy();
            }
        }
    }
}
