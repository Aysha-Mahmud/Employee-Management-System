Create database Shop_DB
go
use Shop_DB
go

CREATE TABLE Positions
(
    PositionId INT          IDENTITY (1, 1) NOT NULL,
    Position   VARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED (PositionId ASC)
);
go
INSERT INTO Positions VALUES
('Shop In Charge'),
('Sales Executive'),
('Executive'),
('Shop Asst.')
go
CREATE TABLE Employee 
(
    EmployeeId INT PRIMARY KEY IDENTITY (1, 1) NOT NULL,
    EmployeeCod NVARCHAR (30) NULL,
    EmployeeName NVARCHAR (50) NULL,
    PositionId INT REFERENCES Positions(PositionId) NULL,
    DOB DATETIME NULL,
    Gender VARCHAR (20)  NULL,
    Status VARCHAR (15)  NULL,
    imagePath  VARCHAR (MAX) NULL
);

go
CREATE TABLE Shop
(
    ShopId   INT           IDENTITY (1, 1) NOT NULL,
    ShopName NVARCHAR (50) NULL,
    PositionId INT  REFERENCES Positions (PositionId)NULL,
    EmployeeId   INT  REFERENCES Employee(EmployeeId)NULL,
    YearOfExp  INT           NULL,
    PRIMARY KEY CLUSTERED (ShopId ASC),
);
go

 CREATE proc ShopAddOrEdit
 @ShopId int ,
 @ShopName varchar(50),
 @positionId int,
 @EmployeeId int,
@YearOfExp int
 As
 if @ShopId = 0
 insert into Shop(ShopName,PositionId,EmployeeId,YearOfExp) values(@ShopName,@PositionId,@EmployeeId,@YearOfExp)

 else 
 update Shop
 set
  ShopName=@ShopName,
  PositionId=@positionId,
  EmployeeId=@EmployeeId,
  YearOfExp=@YearOfExp
  where ShopId=@ShopId
  go

 create proc ShopDelete
 @ShopId int 
 as
 delete from Shop
 where ShopId=@ShopId
 go

 create proc EmployeeAddOrEdit
 @EmployeeId int ,
 @EmployeeCod varchar(30),
 @EmployeeName varchar(50),
 @positionId int,
 @DOB date,
 @Gender varchar(20),
 @Status varchar(15),
 @ImagePath VARCHAR(max)
 As
 if @EmployeeId = 0 begin
 insert into Employee(EmployeeCod,EmployeeName,PositionId,DOB,Gender,Status,imagePath) values(@EmployeeCod,
 @EmployeeName,@PositionId,@DOB,@Gender,@Status,@imagePath)

 select SCOPE_IDENTITY();
 end
 else begin update Employee
 set
 EmployeeCod=@EmployeeCod,
 EmployeeName=@EmployeeName,
 PositionId=@positionId,
 DOB=@DOB,
 Gender=@Gender,
 Status=@Status,
 imagePath=@ImagePath
 where EmployeeId=@EmployeeId
  select @EmployeeId;
  end
go

 create proc EmployeeDelete
 @EmployeeId int 
 as
 delete from Employee
 where EmployeeId=@EmployeeId

  delete from Shop
 where EmployeeId=@EmployeeId

 go

  create proc EmployeeViewAll
 as
select E.EmployeeId,E.EmployeeCod,E.EmployeeName,P.Position,E.Status,E.DOB
from Employee E inner Join Positions P on E.PositionId= P.PositionId
go
 create proc EmployeeViewById
 @EmployeeId int 
 as
 select * from Employee
 where EmployeeId=@EmployeeId

 select * from Shop
 where EmployeeId=@EmployeeId
 go